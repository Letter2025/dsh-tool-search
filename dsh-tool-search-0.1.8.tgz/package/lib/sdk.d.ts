/**
 * Strict `ptc` scopes keep their collapsed tool table (`run_code` only) and
 * carry every tool declaration in the `tools:sdk` prompt section instead. This
 * module re-renders that section from the same disclosed surface the plugin
 * applies to a native table, so deferred tools stop costing prompt tokens while
 * the bridge tools stay callable from inside `run_code`.
 * @module dsh-tool-search/sdk
 */
import { renderToolsSdk } from '@deepseek-ai/dsh-tools';
import type { ToolSchema } from '@deepseek-ai/dsh-llm';
import type { PromptAssembly } from '@deepseek-ai/dsh-system-prompt';
/** The `dsh-tools` prompt section carrying the generated PTC declarations. */
export declare const SDK_SECTION = "tools:sdk";
/**
 * Framing header for the catalog injected into a strict `ptc` scope. The bridge
 * tools are declared there, but a direct call to one fails: only `run_code` is
 * callable by name, so the native header's call instructions would name calls
 * this scope rejects.
 */
export declare const PTC_MANIFEST_HEADER = "Deferred tool catalog \u2014 these tools are NOT declared in the generated SDK. Inside run_code, call `await tools.tool_search({ query })` to rank them and `await tools.tool_describe({ name })` to load a schema, then invoke one with `await tools.<name>({ ... })`. A searched, described, or called tool is declared in your SDK for later turns.";
/** One entry of the declaration list the PTC generators consume. */
export type SdkSchema = Parameters<typeof renderToolsSdk>[0][number];
/** The canonical output schema `dsh-tools` renders for one declared tool. */
export type SdkOutput = SdkSchema['output'];
/**
 * Project the disclosed surface into the declaration list `renderToolsSdk` and
 * `renderToolsSdkPy` consume. `dsh-tools` reads the output schema from the same
 * registry definition.
 * @param tools - the disclosed schemas (eager core plus bridges).
 * @param outputOf - the registered output schema for one tool name, if any.
 * @returns the schemas to declare, in the given order.
 */
export declare function sdkSchemas(tools: readonly ToolSchema[], outputOf: (name: string) => SdkOutput | undefined): SdkSchema[];
/**
 * Rewrite the `tools:sdk` section so it declares only `schemas`. The tool table
 * is left alone: a strict `ptc` scope's table is the `run_code` transport, and
 * replacing it is what removed the transport from the prompt.
 * @param assembly - the settled assembly from the waterfall chain.
 * @param schemas - the declarations the section should carry.
 * @returns the transformed assembly, or the input when it carries no section
 *   this plugin recognizes.
 */
export declare function applySdkSection(assembly: PromptAssembly, schemas: readonly SdkSchema[]): PromptAssembly;
//# sourceMappingURL=sdk.d.ts.map