/**
 * PTC (`run_code`) presentations: the one tool surface this plugin must not
 * transform. `dsh-tools` owns the mode; these helpers read it from the settled
 * assembly, which is the only public surface that carries it.
 * @module dsh-tool-search/ptc
 */
import type { PromptAssembly } from '@deepseek-ai/dsh-system-prompt';
/** The reserved transport tool `dsh-tools` registers for every non-native scope. */
export declare const PTC_TRANSPORT_TOOL = "run_code";
/**
 * Whether this assembly belongs to a scope that presents tools strictly as
 * generated SDK code. Such a scope sees `assembly.tools` collapsed to the
 * `run_code` transport with every declaration moved into the `tools:sdk`
 * section, so replacing the table would remove `run_code` from the prompt and
 * leave the declarations this plugin exists to slim untouched.
 * @param assembly - the settled assembly from the waterfall chain.
 * @returns true when the scope's presentation mode is `ptc`.
 */
export declare function isPtcOnlyAssembly(assembly: PromptAssembly): boolean;
/**
 * The reserved transport this assembly already declares callable by name.
 * A `both` scope keeps native calls beside code ones, so the transport must
 * survive the surface replacement even though it is never a long-tail tool.
 * @param assembly - the settled assembly from the waterfall chain.
 * @returns the transport name when the assembly declares it, otherwise empty.
 */
export declare function transportNamesIn(assembly: PromptAssembly): readonly string[];
//# sourceMappingURL=ptc.d.ts.map