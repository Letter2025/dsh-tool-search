/**
 * dsh-tool-search: Hermes-style tool search & slimming for DeepSeek Harness.
 *
 * When the model-visible tool catalog is large, the `system-prompt/assemble`
 * waterfall replaces the visible tool schemas with three bridge tools
 * (`tool_search` / `tool_describe` / `tool_call`) plus a tiered grouped
 * manifest; long-tail tools are discovered through a configured rerank model
 * and invoked by real name through `ctx.tools.execute`, so approvals, guards,
 * and session events all reference the underlying tool. Core tools stay
 * eager. Tool groups, the rerank matcher, and optional preload live in a
 * runtime config file (`~/.dsh/dsh-tool-search.json` or
 * `<workspace>/.dsh/dsh-tool-search.json`) that the bundled
 * `tool-slimmer-setup` skill writes after conversational setup.
 * @module dsh-tool-search
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ToolSearchConfig } from './types.ts';
export declare const name = "dsh-tool-search";
export declare const inject: string[];
export declare const Config: import("../../../vendor/schemastery/lib/types/index").default<ToolSearchConfig>;
/**
 * Apply the plugin: register the assemble waterfall transform, the three
 * bridge tools, the setup/management tools, and the onboarding skill.
 * @param ctx - the plugin context.
 * @param config - validated static tuning from cordis.yml.
 */
export declare function apply(ctx: Context, config: ToolSearchConfig): void;
//# sourceMappingURL=index.d.ts.map