import type { ToolSchema } from '@deepseek-ai/dsh-llm';
import type { PromptAssembly } from '@deepseek-ai/dsh-system-prompt';
import type { CatalogEntry } from './types.ts';
import { estimateTokens } from './catalog.ts';
/** Disclosure tier of the model-visible tool surface (Hermes tiers). */
export type DisclosureTier = 0 | 1 | 2 | 3;
export declare const MANIFEST_SECTION = "tool-search:catalog";
/** Inputs the tier decision needs; all sizes in tokens except the sizes. */
export interface TierInput {
    /** Total catalog rows (deferred + eager). */
    readonly catalogSize: number;
    /** Rows hidden behind the bridge. */
    readonly deferredSize: number;
    /** Estimated tokens of the full grouped manifest. */
    readonly manifestTokens: number;
    /** Estimated tokens of the names-only grouped manifest. */
    readonly namesOnlyTokens: number;
    /** `min(thresholdPct% × contextWindow, listingMaxTokens)`. */
    readonly budget: number;
    /** Below this catalog size the bridge never activates under `auto`. */
    readonly minCatalogSize: number;
    /** Whether the bridge must activate regardless of catalog size (`on`). */
    readonly forced: boolean;
}
/**
 * Decide the disclosure tier. Tier 0 keeps the surface untouched; tiers 1-3
 * replace it with the bridge plus progressively cheaper listings.
 * @param input - the tier inputs.
 * @returns the tier for this assembly.
 */
export declare function computeTier(input: TierInput): DisclosureTier;
/** The listing budget: `min(thresholdPct% × contextWindow, listingMaxTokens)`. */
export declare function budgetFor(thresholdPct: number, contextWindow: number, listingMaxTokens: number): number;
export interface DisclosureResult {
    readonly tier: DisclosureTier;
    readonly tools: ToolSchema[];
    readonly manifest: string;
}
/**
 * Compute the slimmed model surface for one assembly: eager schemas plus the
 * three bridge schemas, and the manifest text for the current tier.
 * @param entries - the full catalog snapshot.
 * @param eagerNames - tool names that stay directly visible (core + preload).
 * @param bridgeNames - the bridge tool names (always visible).
 * @param tier - the resolved disclosure tier.
 * @returns the slimmed tools and manifest text (empty for tier 0).
 */
export declare function computeDisclosure(entries: readonly CatalogEntry[], eagerNames: ReadonlySet<string>, bridgeNames: ReadonlySet<string>, tier: DisclosureTier): DisclosureResult;
/**
 * Apply the slimmed surface to an assembly: replace `assembly.tools` and, for
 * tiers 1-3, append the manifest as a prompt section. Pure and idempotent —
 * the catalog comes from the registry, never from the incoming assembly.
 * @param assembly - the settled assembly from the waterfall chain.
 * @param disclosure - the computed slimmed surface.
 * @returns the transformed assembly.
 */
export declare function applyDisclosure(assembly: PromptAssembly, disclosure: DisclosureResult): PromptAssembly;
/** Token estimate helpers reused by the engine's tier decision. */
export { estimateTokens };
//# sourceMappingURL=disclosure.d.ts.map