import type { Context } from '@deepseek-ai/cordis';
import type { ToolSchema } from '@deepseek-ai/dsh-llm';
import type { PromptAssembly } from '@deepseek-ai/dsh-system-prompt';
import { RuntimeConfigStore } from './config.ts';
import type { CatalogView, SearchMatch, ToolSearchConfig, UpdateConfigInput, UpdateConfigResult } from './types.ts';
/**
 * The dsh-tool-search engine: resolves runtime config, computes the slimmed
 * model-visible tool surface per assembly, and serves the bridge and setup
 * tools. One instance per plugin load.
 */
export declare class ToolSearchEngine {
    private readonly ctx;
    private readonly config;
    private readonly store;
    /** Session id → preloaded eager tool names (preload cache). */
    private readonly preloaded;
    constructor(ctx: Context, config: ToolSearchConfig, store: RuntimeConfigStore);
    /**
     * Transform one settled assembly: replace `assembly.tools` with the eager
     * core plus bridge tools and append the tiered manifest section. Tier 0 and
     * `enabled: off` return the assembly untouched. Idempotent: the catalog is
     * re-read from the registry on every call.
     * @param assembly - the settled assembly from the waterfall chain.
     * @param scope - the calling agent (or undefined for the global view).
     * @returns the transformed assembly.
     */
    assemble(assembly: PromptAssembly, scope: object | undefined): Promise<PromptAssembly>;
    /**
     * Semantic search over the deferred catalog. Requires a configured matcher;
     * throws with setup guidance when absent.
     * @param query - the model's search query.
     * @param limit - requested result count (clamped to config bounds).
     * @param scope - the calling agent.
     * @returns matches sorted by relevance.
     */
    search(query: string, limit: number | undefined, scope: object | undefined): Promise<SearchMatch[]>;
    /**
     * Resolve the full schema of one catalog tool.
     * @param name - the tool name.
     * @param scope - the calling agent.
     * @returns the model-facing schema fields, or `undefined` when unknown.
     */
    describe(name: string, scope: object | undefined): {
        name: string;
        description: string;
        parameters: ToolSchema['parameters'];
    } | undefined;
    /** The grouped catalog view the setup skill reads to propose grouping. */
    catalogView(scope: object | undefined): Promise<CatalogView>;
    /**
     * Validate and persist a runtime config update, then drop stale caches.
     * @param input - groups/matcher/preload/core changes and the target scope.
     * @param scope - the calling agent (drives the default scope and workspace).
     * @returns the written path, effective scope, and a summary for the model.
     */
    updateConfig(input: UpdateConfigInput, scope: object | undefined): Promise<UpdateConfigResult>;
    private eagerNames;
    private preloadNames;
}
//# sourceMappingURL=engine.d.ts.map